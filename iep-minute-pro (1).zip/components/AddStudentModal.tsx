
import React, { useState } from 'react';
import { Grade, Student, Subject } from '../types';
import { Button } from './Button';

interface AddStudentModalProps {
  onSave: (student: Omit<Student, 'id'>) => void;
  onCancel: () => void;
}

export const AddStudentModal: React.FC<AddStudentModalProps> = ({ onSave, onCancel }) => {
  const [name, setName] = useState('');
  const [grade, setGrade] = useState<Grade>('6th');
  // Store goals as strings to allow user to clear the input completely
  const [goals, setGoals] = useState<Record<Subject, string>>({
    [Subject.MATH]: '30',
    [Subject.ENGLISH]: '30',
    [Subject.TASK_COMPLETION]: '0'
  });

  const handleGoalChange = (subject: Subject, value: string) => {
    // Only allow digits or empty string
    if (value === '' || /^\d+$/.test(value)) {
      setGoals(prev => ({ ...prev, [subject]: value }));
    }
  };

  const handleSave = () => {
    if (!name.trim()) return;

    // Convert string goals back to numbers for the actual data model
    const numericGoals: Record<Subject, number> = {
      [Subject.MATH]: parseInt(goals[Subject.MATH]) || 0,
      [Subject.ENGLISH]: parseInt(goals[Subject.ENGLISH]) || 0,
      [Subject.TASK_COMPLETION]: parseInt(goals[Subject.TASK_COMPLETION]) || 0,
    };

    onSave({ name, grade, subjectGoals: numericGoals });
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 border border-slate-100 animate-in fade-in zoom-in duration-200">
        <h2 className="text-xl font-bold text-slate-900 mb-6">Add New Student</h2>
        
        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-sm font-semibold text-slate-700">Student Name</label>
            <input
              type="text"
              placeholder="Full Name"
              className="w-full p-3 rounded-xl border-2 border-slate-100 focus:border-indigo-500 focus:outline-none"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div className="space-y-1">
            <label className="text-sm font-semibold text-slate-700">Grade Level</label>
            <div className="flex gap-2">
              {(['6th', '7th', '8th'] as Grade[]).map((g) => (
                <button
                  key={g}
                  onClick={() => setGrade(g)}
                  className={`flex-1 py-2 rounded-lg font-bold transition-all ${
                    grade === g 
                      ? 'bg-indigo-600 text-white shadow-md' 
                      : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-sm font-semibold text-slate-700">Weekly Subject Goals (Minutes)</label>
            <div className="grid grid-cols-1 gap-2">
              {Object.values(Subject).map(sub => (
                <div key={sub} className="flex items-center gap-3">
                  <span className="text-xs font-bold text-slate-500 w-24 uppercase">{sub}</span>
                  <input
                    type="text"
                    className="flex-1 p-2 rounded-lg border-2 border-slate-100 focus:border-indigo-500 focus:outline-none text-sm"
                    value={goals[sub]}
                    onChange={(e) => handleGoalChange(sub, e.target.value)}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex gap-3 mt-8">
          <Button variant="outline" className="flex-1" onClick={onCancel}>Cancel</Button>
          <Button 
            variant="primary" 
            className="flex-1" 
            disabled={!name.trim()}
            onClick={handleSave}
          >
            Save Student
          </Button>
        </div>
      </div>
    </div>
  );
};
